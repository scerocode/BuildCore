# BuildCore — Desktop App

VS Code–grade Electron wrapper for the BuildCore browser.

---

## Project Structure

```
/app
  /main
    main.js       ← Electron main process: window, IPC, security
    updater.js    ← Auto-update via electron-updater + GitHub Releases
  /preload
    preload.js    ← contextBridge: exposes bcWindow, bcApp, bcUpdater to renderer
  /renderer
    index.html    ← The full BuildCore app (your existing single-file build)
    state.js      ← Renderer persistence layer (localStorage, namespaced)
    app.js        ← Electron integration: maximize sync, update banner, shortcuts
  /assets
    icon.ico      ← Windows icon  (256×256 minimum, multi-res preferred)
    icon.icns     ← macOS icon    (use iconutil or https://icon.kitchen)
    icon.png      ← Linux icon    (512×512)
    dmg-bg.png    ← macOS DMG background (540×380, optional)
  /build
    entitlements.mac.plist   ← Hardened runtime entitlements for macOS signing
package.json
electron-builder.yml
```

---

## Prerequisites

| Tool         | Version      |
|--------------|-------------|
| Node.js      | 18 LTS or 20 LTS |
| npm          | 9+          |
| Electron     | 29 (installed via devDeps) |

---

## Quick Start (Dev)

```bash
# 1. Install dependencies
npm install

# 2. Run in development mode (DevTools auto-opens)
npm run dev
```

---

## Build Distributables

```bash
# All platforms (current OS only — cross-compilation not supported without Docker)
npm run dist

# Platform-specific
npm run dist:win    # → dist/BuildCore Setup 3.0.0.exe + portable
npm run dist:mac    # → dist/BuildCore-3.0.0.dmg + .zip
npm run dist:linux  # → dist/BuildCore-3.0.0.AppImage + .deb + .rpm
```

Output lands in `/dist`.

---

## Auto-Update Pipeline

### Setup GitHub Releases

1. Create a GitHub repo (`YOUR_GITHUB_USERNAME/buildcore`)
2. Set your repo in `package.json` → `build.publish.owner` and `.repo`
3. Generate a **GitHub Personal Access Token** with `repo` scope
4. Export before releasing:
   ```bash
   export GH_TOKEN=ghp_your_token_here
   ```

### Release a new version

```bash
# Bump version in package.json, then:
npm run release
```

This builds the distributables, creates a GitHub Release, uploads the artifacts, and publishes the `latest.yml` / `latest-mac.yml` files that `electron-updater` polls.

### Update Flow (end-user)

```
App launches
  └─ 10s later: autoUpdater.checkForUpdates()
      └─ new version found → silent background download
          └─ download complete → banner appears in app UI
              ├─ "Restart & Install" → quitAndInstall()
              └─ dismiss → installs on next quit (autoInstallOnAppQuit = true)
```

IPC events the renderer receives:
| `updater:status.state` | Meaning |
|------------------------|---------|
| `checking`             | Polling GitHub Releases |
| `downloading`          | Downloading in background |
| `ready`                | Downloaded, waiting for restart |
| `idle`                 | No update available |
| `error`                | Network/signature failure |

---

## Windows Code Signing (Optional but Recommended)

```bash
# Set these env vars before npm run dist:win
export CSC_LINK=/path/to/certificate.p12
export CSC_KEY_PASSWORD=your_password
```

SmartScreen warnings disappear after ~100–500 user installs on an EV cert,
or immediately with an EV (Extended Validation) certificate.

---

## macOS Code Signing + Notarization

```bash
export CSC_LINK="Developer ID Application: Your Name (TEAMID)"
export CSC_KEY_PASSWORD=your_keychain_password
export APPLE_ID=you@example.com
export APPLE_APP_SPECIFIC_PASSWORD=xxxx-xxxx-xxxx-xxxx
export APPLE_TEAM_ID=YOUR_TEAM_ID

npm run dist:mac
```

`electron-builder` will automatically submit to Apple's notarization service
and staple the ticket. `entitlements.mac.plist` is already configured for
hardened runtime compatibility.

---

## Architecture Notes

**Security model:**
- `contextIsolation: true` + `nodeIntegration: false` — renderer has zero Node access
- All native calls go through the `preload.js` contextBridge
- `<webview>` tabs run in their own renderer processes with isolated partitions
- URL navigation is guarded by `isSafeUrl()` in main.js
- CSP headers injected via `onHeadersReceived`

**Performance:**
- `backgroundThrottling: false` keeps timers accurate in background
- `<webview>` inactive tabs are hidden via CSS (`display:none`) not destroyed — preserves session state while eliminating repaint cost
- No synchronous IPC calls anywhere — all `ipcRenderer.invoke` (async)

**Persistence:**
- `window-state.json` in `app.getPath('userData')` stores window bounds/maximized state
- All app data (tabs, history, notes, sessions, projects) lives in `localStorage` inside the renderer — survives updates automatically
