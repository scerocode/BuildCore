/**
 * generate-icons.js
 * Run once to create placeholder icons for dev builds.
 * For production, replace with your real icons in app/assets/
 *
 * Usage: node scripts/generate-icons.js
 *
 * Requires: npm install canvas  (only needed once for icon generation)
 */

const { createCanvas } = require('canvas');
const fs   = require('fs');
const path = require('path');

const OUT = path.join(__dirname, '..', 'app', 'assets');
fs.mkdirSync(OUT, { recursive: true });

function drawIcon(size) {
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');

  // Background
  const r = size * 0.12;
  ctx.beginPath();
  ctx.moveTo(r, 0); ctx.lineTo(size - r, 0);
  ctx.quadraticCurveTo(size, 0, size, r);
  ctx.lineTo(size, size - r);
  ctx.quadraticCurveTo(size, size, size - r, size);
  ctx.lineTo(r, size);
  ctx.quadraticCurveTo(0, size, 0, size - r);
  ctx.lineTo(0, r);
  ctx.quadraticCurveTo(0, 0, r, 0);
  ctx.closePath();
  const grad = ctx.createLinearGradient(0, 0, size, size);
  grad.addColorStop(0, '#1a1a1a');
  grad.addColorStop(1, '#0d0d0d');
  ctx.fillStyle = grad;
  ctx.fill();

  // "BC" text
  const fs2 = size * 0.38;
  ctx.font = `800 ${fs2}px system-ui, -apple-system, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#D4570A';
  ctx.fillText('BC', size / 2, size / 2);

  return canvas;
}

// PNG (Linux + source for other formats)
const canvas512 = drawIcon(512);
fs.writeFileSync(path.join(OUT, 'icon.png'), canvas512.toBuffer('image/png'));
console.log('✓ icon.png (512×512)');

// For Windows .ico and macOS .icns:
// Use https://icon.kitchen or ImageMagick:
//   convert icon.png -define icon:auto-resize=256,128,64,48,32,16 icon.ico
//   Use iconutil on macOS:
//     mkdir icon.iconset && sips -z 512 512 icon.png --out icon.iconset/icon_512x512.png
//     iconutil -c icns icon.iconset

console.log('\n⚠  For production icons:');
console.log('  Windows: convert icon.png -define icon:auto-resize=256,128,64,48,32,16 icon.ico');
console.log('  macOS:   use iconutil (see README)');
console.log('  Or use:  https://icon.kitchen\n');

// Create empty .ico and .icns placeholders so electron-builder doesn't fail during dev
if (!fs.existsSync(path.join(OUT, 'icon.ico'))) {
  fs.copyFileSync(path.join(OUT, 'icon.png'), path.join(OUT, 'icon.ico'));
  console.log('✓ icon.ico (placeholder — replace with real .ico for production)');
}
if (!fs.existsSync(path.join(OUT, 'icon.icns'))) {
  fs.copyFileSync(path.join(OUT, 'icon.png'), path.join(OUT, 'icon.icns'));
  console.log('✓ icon.icns (placeholder — replace with real .icns for production)');
}
