/**
 * state.js — Renderer persistence layer
 * All reads/writes go through localStorage.
 * Keys are namespaced under 'bc_' to avoid collisions.
 */

const STATE_KEYS = {
  tabs:      'bc_tabs',
  activeTab: 'bc_active_tab',
  history:   'bc_history',
  notes:     'bc_notes',
  settings:  'bc_settings',
  sessions:  'bc_sessions',
  projects:  'bc_ide_projects',
  custom:    'bc_custom_cats',
};

// ─── Generic helpers ─────────────────────────────────────────────────────────
function read(key) {
  try { return JSON.parse(localStorage.getItem(key)); } catch { return null; }
}

function write(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) {
    console.error('State write failed:', key, e);
  }
}

// ─── Settings ────────────────────────────────────────────────────────────────
const DEFAULT_SETTINGS = {
  theme:       'dark',
  fontSize:    13,
  searchEngine: 'https://www.google.com/search?q=',
  newTabUrl:   null,  // legacy key — canonical name is defaultHomeUrl (stored via main IPC)
  defaultHomeUrl: null,
  sidebarWidth: 240,
};

function loadSettings() {
  return { ...DEFAULT_SETTINGS, ...(read(STATE_KEYS.settings) || {}) };
}

function saveSettings(settings) {
  write(STATE_KEYS.settings, settings);
}

// ─── Tabs ────────────────────────────────────────────────────────────────────
function loadTabs() {
  return read(STATE_KEYS.tabs) || [];
}

function saveTabs(tabs) {
  // Strip runtime-only fields before persisting
  const safe = tabs.map(t => ({
    id:          t.id,
    url:         t.url,
    title:       t.title,
    favicon:     t.favicon,
    emoji:       t.emoji,
    partitionId: t.partitionId,
  }));
  write(STATE_KEYS.tabs, safe);
}

function saveActiveTab(id) {
  write(STATE_KEYS.activeTab, id);
}

function loadActiveTab() {
  return read(STATE_KEYS.activeTab);
}

// ─── History ─────────────────────────────────────────────────────────────────
const MAX_HISTORY = 2000;

function loadHistory() {
  return read(STATE_KEYS.history) || [];
}

function appendHistory(entry) {
  const hist = loadHistory();
  // Deduplicate adjacent identical URLs
  if (hist.length && hist[0].url === entry.url) {
    hist[0].ts = entry.ts;
    hist[0].title = entry.title || hist[0].title;
  } else {
    hist.unshift(entry);
    if (hist.length > MAX_HISTORY) hist.length = MAX_HISTORY;
  }
  write(STATE_KEYS.history, hist);
}

function clearHistory() {
  write(STATE_KEYS.history, []);
}

function saveHistory(hist) {
  write(STATE_KEYS.history, hist);
}

// ─── Notes ───────────────────────────────────────────────────────────────────
function loadNotes() {
  return read(STATE_KEYS.notes) || '';
}

function saveNotes(text) {
  write(STATE_KEYS.notes, text);
}

// ─── Export ───────────────────────────────────────────────────────────────────
window.BCState = {
  loadSettings, saveSettings,
  loadTabs,     saveTabs,
  saveActiveTab, loadActiveTab,
  loadHistory,  appendHistory, clearHistory, saveHistory,
  loadNotes,    saveNotes,
  KEYS: STATE_KEYS,
};
