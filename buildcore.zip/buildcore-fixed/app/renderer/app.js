/**
 * app.js — Electron integration layer for the renderer.
 * Loaded after state.js and before the main app bundle.
 * Patches bcWindow, wires updater UI, and bootstraps platform behavior.
 */

(function () {
  'use strict';

  // ── Guard: only run inside Electron ────────────────────────────────────────
  const inElectron = typeof window.bcWindow !== 'undefined';

  // ── Platform class on <html> for CSS targeting ──────────────────────────────
  if (inElectron) {
    window.bcWindow.platform().then(p => {
      document.documentElement.dataset.platform = p; // 'darwin' | 'win32' | 'linux'
    });
  }

  // ── Maximize state sync ─────────────────────────────────────────────────────
  if (inElectron) {
    window.bcWindow.isMaximized().then(maximized => {
      document.documentElement.classList.toggle('maximized', maximized);
    });
    // [SEC] onMaximized renamed to onState to carry a full state object
    window.bcWindow.onState(d => {
      document.documentElement.classList.toggle('maximized', d.maximized);
      const btn = document.getElementById('win-max');
      if (btn) btn.title = d.maximized ? 'Restore' : 'Maximize';
    });
  }

  // ── Version in about panel ──────────────────────────────────────────────────
  if (inElectron) {
    window.bcApp.version().then(v => {
      const el = document.getElementById('app-version');
      if (el) el.textContent = v.version;
    });
  }

  // ── Auto-updater UI ─────────────────────────────────────────────────────────
  if (inElectron) {
    const BANNER_ID = 'update-banner';

    function getOrCreateBanner() {
      let el = document.getElementById(BANNER_ID);
      if (el) return el;
      el = document.createElement('div');
      el.id = BANNER_ID;
      el.style.cssText = [
        'position:fixed', 'bottom:32px', 'right:20px', 'z-index:99999',
        'background:var(--s3,#1e1e1e)', 'border:1px solid var(--bd3,#3a3a3a)',
        'border-radius:8px', 'padding:10px 14px', 'display:flex',
        'align-items:center', 'gap:10px', 'font-size:12px',
        'color:var(--t1,#e8e8e8)', 'box-shadow:0 4px 24px rgba(0,0,0,.6)',
        'transform:translateY(8px)', 'opacity:0',
        'transition:opacity .2s,transform .2s',
      ].join(';');
      document.body.appendChild(el);
      requestAnimationFrame(() => {
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      });
      return el;
    }

    function hideBanner() {
      const el = document.getElementById(BANNER_ID);
      if (!el) return;
      el.style.opacity = '0';
      el.style.transform = 'translateY(8px)';
      setTimeout(() => el.remove(), 250);
    }

    window.bcUpdater.onStatus(({ state, version, message }) => {
      if (state === 'idle' || state === 'checking') return;

      if (state === 'ready') {
        const banner = getOrCreateBanner();
        banner.innerHTML = `
          <span>🚀 Update <strong>v${version}</strong> ready</span>
          <button onclick="window.bcUpdater.installNow()"
            style="background:var(--a,#d4570a);border:none;border-radius:5px;
                   color:#fff;padding:4px 10px;cursor:pointer;font-size:11px">
            Restart &amp; Install
          </button>
          <button onclick="(${hideBanner.toString()})()"
            style="background:none;border:none;color:var(--t4,#888);cursor:pointer;font-size:16px;line-height:1">
            ×
          </button>`;
      }

      if (state === 'error') {
        console.warn('[updater] error:', message);
      }
    });

    window.bcUpdater.onProgress(({ percent }) => {
      const banner = getOrCreateBanner();
      banner.innerHTML = `
        <span>Downloading update… <strong>${percent}%</strong></span>
        <div style="flex:1;height:3px;background:var(--s4,#333);border-radius:2px;min-width:80px">
          <div style="width:${percent}%;height:100%;background:var(--a,#d4570a);border-radius:2px;transition:width .3s"></div>
        </div>`;
    });
  }

  // ── Keyboard shortcuts that need native awareness ───────────────────────────
  // Ctrl+Q / Cmd+Q → quit
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'q') {
      if (inElectron) window.bcWindow.close();
    }
  });

  // ── Drag region: double-click titlebar to maximize/restore ─────────────────
  document.addEventListener('dblclick', e => {
    if (!inElectron) return;
    const tb = document.getElementById('titlebar');
    if (!tb) return;
    // Only if click was directly on the titlebar drag region
    const target = e.target;
    if (tb.contains(target) && !target.closest('button, input, a, [onclick]')) {
      window.bcWindow.maximize();
    }
  });

})();
