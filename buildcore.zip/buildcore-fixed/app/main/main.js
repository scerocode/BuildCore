'use strict';
// ╔══════════════════════════════════════════════════════════════════════════╗
// ║  BuildCore — main process                                               ║
// ║  Security hardening audit — all changes annotated with [SEC-N]          ║
// ╚══════════════════════════════════════════════════════════════════════════╝

const {
  app, BrowserWindow, ipcMain, session,
  nativeTheme, shell, protocol, net, dialog
} = require('electron');
const path  = require('path');
const fs    = require('fs');
const { setupUpdater } = require('./updater');

// ─── Single-instance lock ────────────────────────────────────────────────────
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { app.quit(); process.exit(0); }

// ─── Paths ───────────────────────────────────────────────────────────────────
const USER_DATA    = app.getPath('userData');
const SETTINGS_F   = path.join(USER_DATA, 'window-state.json');
const RENDERER_DIR = path.resolve(path.join(__dirname, '..', 'renderer'));
const RENDERER     = path.join(RENDERER_DIR, 'index.html');
const DATA_DIR     = path.join(USER_DATA, 'appdata');   // isolated data directory

// Ensure the data directory exists on first run
fs.mkdirSync(DATA_DIR, { recursive: true });

// ─── [SEC-1] Trusted-site allowlist ─────────────────────────────────────────
// Add hostnames webviews are allowed to visit.
// When EMPTY: any HTTPS site is permitted (open mode — suitable for general browser).
// When populated: ONLY listed hostnames and their subdomains are permitted.
const TRUSTED_HOSTS = new Set([
  // 'github.com',
  // 'notion.so',
]);

// ─── [SEC-2] URL safety check ─────────────────────────────────────────────────
// Single authoritative function used in both main (webview navigation guard)
// and exposed to renderer via IPC (pre-navigation UI check).
// file:// is unconditionally blocked — a webview must never reach the local FS.
function isSafeUrl(url) {
  try {
    const u = new URL(url);
    if (!['https:', 'about:', 'blob:', 'data:'].includes(u.protocol)) return false;
    if (!u.hostname) return true;                         // about:blank, blob:, data: URIs
    if (TRUSTED_HOSTS.size === 0) return true;            // open mode
    for (const h of TRUSTED_HOSTS) {
      if (u.hostname === h || u.hostname.endsWith('.' + h)) return true;
    }
    return false;
  } catch { return false; }
}

// ─── [SEC-3] IPC sender validation ───────────────────────────────────────────
// Ensures IPC calls originate from our BrowserWindow renderer, not a webview
// guest or a compromised frame. Called at the top of every sensitive handler.
//
// Threat: A hostile webpage inside a <webview> that somehow gains a reference
// to ipcRenderer (impossible with our config, but defence-in-depth) should
// still be blocked at the main-process gate.
function assertMainRenderer(event) {
  // event.senderFrame.url is the URL of the frame that sent the IPC call.
  // Our renderer always loads from file:// (local renderer/index.html).
  const senderUrl = event.senderFrame?.url ?? '';
  if (!senderUrl.startsWith('file://')) {
    throw new Error(`[security] IPC call rejected from non-local frame: ${senderUrl}`);
  }
}

// ─── Window state persistence ────────────────────────────────────────────────
function loadWindowState() {
  try {
    const raw = JSON.parse(fs.readFileSync(SETTINGS_F, 'utf8'));
    // Validate shape — only accept expected numeric/boolean fields
    return {
      width:     (typeof raw.width  === 'number' && raw.width  > 100) ? raw.width  : 1280,
      height:    (typeof raw.height === 'number' && raw.height > 100) ? raw.height : 820,
      x:         (typeof raw.x === 'number') ? raw.x : undefined,
      y:         (typeof raw.y === 'number') ? raw.y : undefined,
      maximized: raw.maximized === true,
    };
  } catch { return { width: 1280, height: 820 }; }
}

function saveWindowState(win) {
  try {
    fs.writeFileSync(SETTINGS_F, JSON.stringify({
      ...win.getBounds(),
      maximized: win.isMaximized(),
    }));
  } catch {}
}

// ─── [SEC-4] Per-partition session hardening ──────────────────────────────────
// Applied to every webview session object. Each tab gets its own Chromium
// partition so cookies/storage/auth are fully isolated between tabs.

// Track hardened sessions — hardenSession is called on 'dom-ready' which fires
// on every navigation. Without this guard, each navigation stacks a new
// onHeadersReceived listener on the same session object, causing headers to be
// mutated N times for N navigations (N stacked interceptors).
const _hardenedSessions = new WeakSet();

function hardenSession(ses) {
  // Guard: only harden each session once — dom-ready fires on every navigation
  if (_hardenedSessions.has(ses)) return;
  _hardenedSessions.add(ses);

  ses.webRequest.onHeadersReceived((details, cb) => {
    const h = details.responseHeaders;

    // ── Baseline CSP floor (only injected if site sets none) ──────────────
    if (!h['content-security-policy'] && !h['Content-Security-Policy']) {
      h['Content-Security-Policy'] = [
        "default-src 'self' https:; " +
        "script-src 'self' https:; " +
        "style-src 'self' 'unsafe-inline' https:; " +
        "img-src 'self' data: blob: https:; " +
        "media-src 'self' blob: https:; " +
        "connect-src 'self' https: wss:; " +
        "font-src 'self' data: https:; " +
        "frame-src 'self' blob: https:; " +
        "object-src 'none'; base-uri 'self';"
      ];
    }

    // ── CORP / COEP header workaround ──────────────────────────────────────
    // Sites like claude.ai and Google set:
    //   Cross-Origin-Resource-Policy: same-origin
    //   Cross-Origin-Embedder-Policy: require-corp
    // In a standard browser these protect the site from being embedded in
    // foreign origins. In our app each webview tab runs in its own isolated
    // Chromium partition — the partition IS the origin boundary.
    //
    // However, CORP: same-origin causes Chromium to block subresource loads
    // (favicons, API responses) that are requested from our renderer's
    // file:// origin via <img> tags and XHR. The renderer proxy approach in
    // the frontend (faviconUrl) handles the <img> case. Stripping CORP here
    // handles any remaining fetch() or XHR cases from within the webview
    // itself that might cross the guest↔renderer boundary.
    //
    // Security tradeoff: We only strip these in webview partitions (hardenSession
    // is only called for webview sessions). The main renderer session is NOT
    // touched. This is acceptable: partition isolation provides equivalent
    // protection — no two tabs share cookies, storage, or auth tokens.
    delete h['cross-origin-resource-policy'];
    delete h['Cross-Origin-Resource-Policy'];
    delete h['cross-origin-embedder-policy'];
    delete h['Cross-Origin-Embedder-Policy'];
    // Keep COOP — it prevents popup navigation attacks and is harmless here
    // delete h['cross-origin-opener-policy'];  // intentionally NOT removed

    h['X-Content-Type-Options'] = ['nosniff'];
    cb({ responseHeaders: h });
  });

  ses.setPermissionRequestHandler((wc, permission, cb) => {
    cb(['media', 'clipboard-read', 'clipboard-sanitized-write',
        'notifications', 'fullscreen'].includes(permission));
  });
  ses.setPermissionCheckHandler((wc, permission) =>
    ['media', 'clipboard-read', 'clipboard-sanitized-write',
     'notifications', 'fullscreen'].includes(permission));
}

// ─── Data file helpers ────────────────────────────────────────────────────────
// [SEC-5] All file I/O is confined to DATA_DIR.
// Path traversal prevention: resolve and verify prefix before any read/write.
const SAFE_DATA_FILES = new Set(['settings.json', 'history.json', 'notes.txt', 'tabs.json']);

function safeDataPath(filename) {
  if (!SAFE_DATA_FILES.has(filename)) throw new Error('Disallowed filename: ' + filename);
  const resolved = path.resolve(path.join(DATA_DIR, filename));
  if (!resolved.startsWith(DATA_DIR + path.sep) && resolved !== DATA_DIR) {
    throw new Error('Path traversal attempt blocked');
  }
  return resolved;
}

function readDataFile(filename) {
  try { return fs.readFileSync(safeDataPath(filename), 'utf8'); }
  catch { return null; }
}

function writeDataFile(filename, content) {
  if (typeof content !== 'string') throw new Error('Content must be a string');
  if (content.length > 50 * 1024 * 1024) throw new Error('Data too large (50MB limit)');
  fs.writeFileSync(safeDataPath(filename), content, 'utf8');
}

// ─── Main window ──────────────────────────────────────────────────────────────
let mainWin = null;

function createWindow() {
  const ws = loadWindowState();

  mainWin = new BrowserWindow({
    width:  ws.width,
    height: ws.height,
    x: ws.x,
    y: ws.y,
    minWidth: 800, minHeight: 540,
    frame: false,
    titleBarStyle: 'hidden',
    trafficLightPosition: { x: 14, y: 12 },
    backgroundColor: '#0d0d0d',
    show: false,
    webPreferences: {
      preload:              path.join(__dirname, '..', 'preload', 'preload.js'),
      contextIsolation:     true,
      // [SEC-6] sandbox: false is a deliberate, documented exception.
      // Rationale: Electron requires sandbox:false on the host BrowserWindow
      // when webviewTag:true is set, because the webview IPC bridge between
      // the renderer and each webview guest needs Node.js in the preload.
      // Mitigations: (a) preload exposes only contextBridge APIs, never raw
      // Node/Electron objects; (b) every webview guest runs with sandbox:true;
      // (c) IPC handlers validate event.senderFrame.url.
      sandbox:              false,
      nodeIntegration:      false,
      webviewTag:           true,
      spellcheck:           false,
      backgroundThrottling: false,
      allowRunningInsecureContent: false,
      experimentalFeatures: false,
    },
  });

  // ── [SEC-7] Renderer CSP ────────────────────────────────────────────────
  // The renderer is our own trusted HTML+JS. We must allow 'unsafe-inline'
  // because the UI has 133 inline event handlers (removing them would require
  // a full refactor — tracked as a future hardening task).
  // 'unsafe-eval' is removed: the UI does not use eval(). If a third-party
  // script needs it, it must be refactored or replaced.
  mainWin.webContents.session.webRequest.onHeadersReceived((details, cb) => {
    cb({
      responseHeaders: {
        ...details.responseHeaders,
        'Content-Security-Policy': [
          "default-src 'self' 'unsafe-inline' data: blob:; " +
          "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; " +
          // Note: ^^ cdnjs is allowlisted for JSZip (IDE feature). Hardened
          // below by requiring SRI on the dynamic script load.
          // [FIX-1] style-src-elem must be explicit: without it Chromium falls back
          // to default-src which has no external origin, blocking the
          // fonts.googleapis.com <link> element. font-src covers the .woff2 binaries
          // from fonts.gstatic.com (the delivery CDN, distinct from the CSS host).
          "style-src-elem 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
          "img-src 'self' data: blob: https:; " +
          "font-src 'self' data: https://fonts.gstatic.com; " +
          "connect-src 'self' https:; " +
          "object-src 'none'; base-uri 'self';"
        ],
        'X-Content-Type-Options': ['nosniff'],
      },
    });
  });

  mainWin.webContents.session.setPermissionRequestHandler((wc, perm, cb) => {
    cb(['media', 'clipboard-read', 'clipboard-sanitized-write',
        'notifications', 'fullscreen'].includes(perm));
  });

  // ── Crash recovery for main renderer ────────────────────────────────────
  // If the renderer process itself crashes (rare but possible with heavy webview
  // use or GPU issues), reload automatically rather than showing a blank window.
  mainWin.webContents.on('render-process-gone', (_, details) => {
    console.error('[main] Renderer process gone:', details.reason);
    if (details.reason !== 'clean-exit') {
      // Give the GPU time to settle then reload
      setTimeout(() => {
        if (!mainWin.isDestroyed()) mainWin.loadFile(RENDERER);
      }, 500);
    }
  });

  // ── [SEC-8] Prevent renderer from navigating away ────────────────────────
  // The main window must ONLY ever load our local renderer file.
  // Any navigation attempt (e.g. from a compromised renderer) is blocked.
  mainWin.webContents.on('will-navigate', (ev, url) => {
    const resolved = path.resolve(url.replace('file://', ''));
    if (!url.startsWith('file://') || !resolved.startsWith(RENDERER_DIR)) {
      console.warn('[security] Blocked renderer navigation to:', url);
      ev.preventDefault();
    }
  });
  mainWin.webContents.on('will-redirect', ev => ev.preventDefault());

  mainWin.loadFile(RENDERER);
  mainWin.once('ready-to-show', () => {
    if (ws.maximized) mainWin.maximize();
    mainWin.show();
    mainWin.focus();
  });

  mainWin.on('maximize',   () => mainWin.webContents.send('window:state', { maximized: true }));
  mainWin.on('unmaximize', () => mainWin.webContents.send('window:state', { maximized: false }));
  mainWin.on('close',  () => saveWindowState(mainWin));
  mainWin.on('closed', () => { mainWin = null; });

  // ── Dev tools ─────────────────────────────────────────────────────────────
  if (process.env.NODE_ENV === 'development') {
    mainWin.webContents.openDevTools({ mode: 'detach' });
  }

  setupUpdater(mainWin);
}

// ─── [SEC-9] Secure every webview created in this process ────────────────────
// Registered ONCE at module level — NOT inside createWindow — so the listener
// is not duplicated on macOS when the window is closed and recreated via 'activate'.
app.on('web-contents-created', (_, wc) => {
  if (wc.getType() !== 'webview') return;

  // Strip any preload the page tries to inject and force safe prefs.
  wc.on('will-attach-webview', (_, webPrefs) => {
    delete webPrefs.preload;
    delete webPrefs.preloadURL;
    webPrefs.contextIsolation             = true;
    webPrefs.nodeIntegration              = false;
    webPrefs.nodeIntegrationInSubFrames   = false;
    webPrefs.sandbox                      = true;
    webPrefs.allowRunningInsecureContent  = false;
  });

  // Popup / window.open() handling for OAuth and login flows.
  //
  // AI sites (claude.ai, ChatGPT, etc.) use window.open() for:
  //   - Google / GitHub / Microsoft OAuth popups
  //   - "Continue with Google" modals
  //   - Payment / verification flows
  //
  // BEFORE (broken): All popups were sent to the system browser via
  //   shell.openExternal(). This broke login because:
  //   1. The auth cookie is set inside the popup on the site's domain.
  //   2. In the system browser the cookie lives in a DIFFERENT profile,
  //      so when the popup closes and redirects back, the parent webview
  //      can't see the auth token → login fails silently.
  //
  // AFTER (fixed): We return { action: 'allow' } so Electron creates
  //   the popup inside the app using the SAME partition as the parent
  //   webview. Auth cookies are shared and login completes normally.
  //   We still block unsafe URLs (non-https, file://, etc.).
  wc.setWindowOpenHandler(({ url, frameName, features }) => {
    if (!isSafeUrl(url)) {
      console.warn('[security] Blocked popup to unsafe URL:', url);
      return { action: 'deny' };
    }
    // Allow the popup to open inside Electron (same partition = shared cookies).
    // overrideBrowserWindowOptions lets us give it sensible dimensions.
    return {
      action: 'allow',
      overrideBrowserWindowOptions: {
        width:           520,
        height:          660,
        modal:           false,
        autoHideMenuBar: true,
        backgroundColor: '#0d0d0d',
        webPreferences: {
          contextIsolation:            true,
          nodeIntegration:             false,
          sandbox:                     true,
          allowRunningInsecureContent: false,
        },
      },
    };
  });

  wc.on('will-navigate', (ev, url) => { if (!isSafeUrl(url)) { console.warn('[security] Blocked webview navigation:', url); ev.preventDefault(); } });
  wc.on('will-redirect', (ev, url) => { if (!isSafeUrl(url)) { console.warn('[security] Blocked webview redirect:', url); ev.preventDefault(); } });

  // Apply per-partition session hardening once the webview is ready
  wc.on('dom-ready', () => hardenSession(wc.session));
});

// Single-instance focus handler — registered once at module level.
app.on('second-instance', () => {
  if (!mainWin) return;
  if (mainWin.isMinimized()) mainWin.restore();
  mainWin.focus();
});

// ═══════════════════════════════════════════════════════════════════════════════
//  IPC HANDLERS — registered ONCE at module level, NOT inside createWindow.
//  All handlers use the module-level `mainWin` reference (nullable-safe via ?.),
//  so they work correctly whether the window has been recreated or not.
//  Registering inside createWindow caused ipcMain.handle to throw
//  "Attempted to register a second handler" on macOS after window close/reopen.
// ═══════════════════════════════════════════════════════════════════════════════

// ── Titlebar ──────────────────────────────────────────────────────────────────
ipcMain.handle('window:minimize',    (ev) => { assertMainRenderer(ev); mainWin?.minimize(); });
ipcMain.handle('window:maximize',    (ev) => {
  assertMainRenderer(ev);
  if (!mainWin) return;
  mainWin.isMaximized() ? mainWin.unmaximize() : mainWin.maximize();
});
ipcMain.handle('window:close',       (ev) => { assertMainRenderer(ev); mainWin?.close(); });
ipcMain.handle('window:isMaximized', (ev) => { assertMainRenderer(ev); return mainWin?.isMaximized() ?? false; });
ipcMain.handle('window:platform',    (ev) => { assertMainRenderer(ev); return process.platform; });

// ── App info ──────────────────────────────────────────────────────────────────
// [SEC-10] Returns full version object the renderer's about panel expects.
ipcMain.handle('app:version', (ev) => {
  assertMainRenderer(ev);
  return {
    version:  app.getVersion(),
    electron: process.versions.electron,
    chrome:   process.versions.chrome,
    node:     process.versions.node,
    platform: process.platform,
    arch:     process.arch,
  };
});

ipcMain.handle('app:userData', (ev) => {
  assertMainRenderer(ev);
  return USER_DATA;
});

// [SEC-11] openPath: only permits opening DATA_DIR itself, not arbitrary paths
ipcMain.handle('app:openPath', (ev) => {
  assertMainRenderer(ev);
  shell.openPath(DATA_DIR);
});

// ── Persistent data (history / settings / notes / tabs) ───────────────────────
// [SEC-12] Data stored in DATA_DIR as JSON files; renderer gets only parsed objects.

// Settings
ipcMain.handle('data:settings:get', (ev) => {
  assertMainRenderer(ev);
  const raw = readDataFile('settings.json');
  return raw ? JSON.parse(raw) : {};
});
ipcMain.handle('data:settings:update', (ev, patch) => {
  assertMainRenderer(ev);
  if (!patch || typeof patch !== 'object' || Array.isArray(patch)) throw new Error('Invalid patch');
  const ALLOWED_KEYS = new Set(['theme','fontSize','searchEngine','defaultHomeUrl',
                                'sidebarWidth','showStatusBar','sidebarCollapsed']);
  const raw = readDataFile('settings.json');
  const current = raw ? JSON.parse(raw) : {};
  const sanitized = {};
  for (const [k, v] of Object.entries(patch)) {
    if (ALLOWED_KEYS.has(k)) sanitized[k] = v;
  }
  const merged = { ...current, ...sanitized };
  writeDataFile('settings.json', JSON.stringify(merged));
  return merged;
});

// History
ipcMain.handle('data:history:get', (ev) => {
  assertMainRenderer(ev);
  const raw = readDataFile('history.json');
  return raw ? JSON.parse(raw) : [];
});
ipcMain.handle('data:history:add', (ev, entry) => {
  assertMainRenderer(ev);
  if (!entry || typeof entry.url !== 'string') throw new Error('Invalid history entry');
  const safe = {
    url:       entry.url.slice(0, 2048),
    title:     (entry.title || '').slice(0, 512),
    favicon:   (entry.favicon || '').slice(0, 512),
    timestamp: Date.now(),
  };
  const raw   = readDataFile('history.json');
  const hist  = raw ? JSON.parse(raw) : [];
  if (hist.length && hist[0].url === safe.url) {
    hist[0].timestamp = safe.timestamp;
    hist[0].title     = safe.title || hist[0].title;
  } else {
    hist.unshift(safe);
    if (hist.length > 2000) hist.length = 2000;
  }
  writeDataFile('history.json', JSON.stringify(hist));
  return true;
});
ipcMain.handle('data:history:clear', (ev) => {
  assertMainRenderer(ev);
  writeDataFile('history.json', '[]');
  return true;
});
ipcMain.handle('data:history:export', async (ev) => {
  assertMainRenderer(ev);
  // [SEC-13] Dialog is opened by main — renderer cannot control save path
  const result = await dialog.showSaveDialog(mainWin, {
    title:       'Export History',
    defaultPath: 'buildcore-history.json',
    filters:     [{ name: 'JSON', extensions: ['json'] }],
  });
  if (result.canceled || !result.filePath) return { canceled: true };
  const resolved = path.resolve(result.filePath);
  const appPath  = path.resolve(app.getAppPath());
  if (resolved.startsWith(appPath)) throw new Error('Cannot write inside app bundle');
  const raw = readDataFile('history.json');
  fs.writeFileSync(resolved, raw || '[]', 'utf8');
  return { filePath: result.filePath };
});

// Notes
ipcMain.handle('data:notes:get', (ev) => {
  assertMainRenderer(ev);
  return readDataFile('notes.txt') || '';
});
ipcMain.handle('data:notes:save', (ev, text) => {
  assertMainRenderer(ev);
  if (typeof text !== 'string') throw new Error('Notes must be a string');
  writeDataFile('notes.txt', text.slice(0, 1024 * 1024)); // 1MB cap
  return true;
});

// Tabs
ipcMain.handle('data:tabs:get', (ev) => {
  assertMainRenderer(ev);
  const raw = readDataFile('tabs.json');
  return raw ? JSON.parse(raw) : [];
});
ipcMain.handle('data:tabs:save', (ev, tabs) => {
  assertMainRenderer(ev);
  if (!Array.isArray(tabs)) throw new Error('Tabs must be an array');
  if (tabs.length > 200) throw new Error('Too many tabs (max 200)');
  const safe = tabs.map(t => ({
    id:          String(t.id          || '').slice(0, 64),
    url:         String(t.url         || '').slice(0, 2048),
    title:       String(t.title       || '').slice(0, 512),
    favicon:     String(t.favicon     || '').slice(0, 512),
    emoji:       String(t.emoji       || '').slice(0, 8),
    partitionId: String(t.partitionId || '').slice(0, 64),
  }));
  writeDataFile('tabs.json', JSON.stringify(safe));
  return true;
});

// ── Webview / session ──────────────────────────────────────────────────────────
ipcMain.handle('webview:clearSession', async (ev, partitionId) => {
  assertMainRenderer(ev);
  if (typeof partitionId !== 'string') throw new Error('Invalid type');
  // [SEC-14] Strict allowlist regex — only tab-generated partition IDs accepted
  if (!/^tab-[a-z0-9]{6,20}$/.test(partitionId)) throw new Error('Invalid partitionId format');
  const ses = session.fromPartition('persist:' + partitionId, { cache: true });
  await Promise.all([
    ses.clearStorageData(),
    ses.clearCache(),
    ses.clearHostResolverCache(),
    ses.clearAuthCache(),
  ]);
  return true;
});

ipcMain.handle('webview:isSafeUrl', (ev, url) => {
  assertMainRenderer(ev);
  if (typeof url !== 'string' || url.length > 2048) return false;
  return isSafeUrl(url);
});

ipcMain.handle('webview:trustedHosts', (ev) => {
  assertMainRenderer(ev);
  return { hosts: [...TRUSTED_HOSTS], openMode: TRUSTED_HOSTS.size === 0 };
});

// ─── [SEC-15] Custom protocol: path traversal fix ────────────────────────────
// BEFORE: filePath could contain '../' sequences reaching outside renderer dir.
// AFTER:  Resolved path must start with RENDERER_DIR or the request is denied.
app.whenReady().then(() => {
  protocol.handle('app', req => {
    const reqPath = req.url.slice('app://'.length).split('?')[0]; // strip query
    const resolved = path.resolve(path.join(RENDERER_DIR, reqPath));
    if (!resolved.startsWith(RENDERER_DIR + path.sep) && resolved !== RENDERER_DIR) {
      console.warn('[security] Protocol traversal blocked:', reqPath, '->', resolved);
      return new Response('Forbidden', { status: 403 });
    }
    return net.fetch('file://' + resolved);
  });

  nativeTheme.themeSource = 'dark';
  createWindow();
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
app.on('before-quit', () => ipcMain.removeAllListeners());
