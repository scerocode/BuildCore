'use strict';

const { autoUpdater }    = require('electron-updater');
const { ipcMain, dialog } = require('electron');
const log                = require('electron-log');

autoUpdater.logger       = log;
autoUpdater.logger.transports.file.level = 'info';
autoUpdater.autoDownload = true;
autoUpdater.autoInstallOnAppQuit = true;

// Shared sender validation (duplicated here to avoid circular require with main.js)
function assertMainRenderer(event) {
  const senderUrl = event.senderFrame?.url ?? '';
  if (!senderUrl.startsWith('file://')) {
    throw new Error(`[security] Updater IPC rejected from non-local frame: ${senderUrl}`);
  }
}

// Module-level reference to the main window — updated each time setupUpdater is called.
// IPC handlers are registered ONCE (below) and close over this reference.
let _mainWin = null;

function send(channel, data = {}) {
  if (_mainWin && !_mainWin.isDestroyed()) {
    _mainWin.webContents.send('updater:' + channel, data);
  }
}

// ── IPC handlers — registered exactly ONCE at module load time ──────────────
// Registering inside setupUpdater() caused "second handler" errors on macOS
// when the window was closed and re-opened via the dock (activate event).
ipcMain.handle('updater:check', (ev) => {
  assertMainRenderer(ev);
  return autoUpdater.checkForUpdates();
});

// [SEC-F] Install gate: require native confirmation before restarting.
ipcMain.handle('updater:install', async (ev) => {
  assertMainRenderer(ev);
  const { response } = await dialog.showMessageBox(_mainWin, {
    type:    'question',
    buttons: ['Restart & Install', 'Cancel'],
    defaultId: 0, cancelId: 1,
    title:   'Install Update',
    message: 'Restart BuildCore to install the update?',
    detail:  'Any unsaved work will be lost.',
  });
  if (response === 0) autoUpdater.quitAndInstall(false, true);
});

ipcMain.handle('updater:installOnQuit', (ev) => {
  assertMainRenderer(ev);
  autoUpdater.autoInstallOnAppQuit = true;
});

// ── autoUpdater events — registered once, use send() which reads _mainWin ───
autoUpdater.on('checking-for-update',  ()     => send('status', { state: 'checking' }));
autoUpdater.on('update-available',     info   => send('status', { state: 'downloading', version: info.version }));
autoUpdater.on('update-not-available', ()     => send('status', { state: 'idle' }));
autoUpdater.on('download-progress',    prog   => send('progress', { state: 'downloading', percent: Math.round(prog.percent), speed: prog.bytesPerSecond, total: prog.total }));
autoUpdater.on('update-downloaded',    info   => send('status', { state: 'ready', version: info.version }));
autoUpdater.on('error',                err    => { log.error('Updater error:', err); send('status', { state: 'error', message: err.message }); });

// ── setupUpdater — called each time a new window is created ─────────────────
// Just updates the window reference and kicks off the first update check.
function setupUpdater(mainWin) {
  _mainWin = mainWin;
  setTimeout(
    () => autoUpdater.checkForUpdates().catch(e => log.warn('Update check skipped:', e.message)),
    10_000
  );
  setInterval(
    () => autoUpdater.checkForUpdates().catch(e => log.warn('Update check skipped:', e.message)),
    4 * 60 * 60 * 1000
  );
}

module.exports = { setupUpdater };
