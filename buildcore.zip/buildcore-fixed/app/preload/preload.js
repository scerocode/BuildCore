'use strict';
// ╔══════════════════════════════════════════════════════════════════════════╗
// ║  BuildCore — preload (security boundary)                                ║
// ║  Threat model: treat the renderer as untrusted.                         ║
// ║  Rules:                                                                 ║
// ║  • NEVER expose ipcRenderer, require, fs, path, or any Node API        ║
// ║  • NEVER expose a generic "invoke any channel" function                 ║
// ║  • Each exposed method maps to exactly ONE named IPC channel            ║
// ║  • Input validation happens here (first gate) AND in main (second gate) ║
// ║  • Event listeners use a clone of the data, never raw IPC event        ║
// ╚══════════════════════════════════════════════════════════════════════════╝

const { contextBridge, ipcRenderer } = require('electron');

// ─── Internal helper: validated invoke ───────────────────────────────────────
// Wraps ipcRenderer.invoke with a local type check so we never send obviously
// garbage data to the main process.
function invoke(channel, ...args) {
  return ipcRenderer.invoke(channel, ...args);
}

// ─── Window controls ──────────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('bcWindow', {
  minimize:    () => invoke('window:minimize'),
  maximize:    () => invoke('window:maximize'),
  close:       () => invoke('window:close'),
  isMaximized: () => invoke('window:isMaximized'),
  platform:    () => invoke('window:platform'),

  // [SEC-A] Listener returns a plain cloned value, never the raw IPC event.
  // The unsubscribe function is returned so the renderer can clean up.
  onState: (cb) => {
    if (typeof cb !== 'function') return () => {};
    const handler = (_, data) => {
      // Validate shape before forwarding to renderer
      if (data && typeof data === 'object') cb({ maximized: !!data.maximized });
    };
    ipcRenderer.on('window:state', handler);
    return () => ipcRenderer.off('window:state', handler);
  },
});

// ─── App info ─────────────────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('bcApp', {
  // Returns {version, electron, chrome, node, platform, arch}
  version:  () => invoke('app:version'),
  // Returns the userData path string (for display in Settings only)
  userData: () => invoke('app:userData'),
});

// ─── Persistent data APIs ─────────────────────────────────────────────────────
// [SEC-B] Previously missing: bcHistory, bcSettings, bcNotes, bcTabs
// These replace direct localStorage calls for data that must persist
// across sessions and may eventually need main-process validation.

contextBridge.exposeInMainWorld('bcSettings', {
  get:    ()      => invoke('data:settings:get'),
  update: (patch) => {
    if (!patch || typeof patch !== 'object' || Array.isArray(patch)) return Promise.reject(new Error('Invalid patch'));
    return invoke('data:settings:update', patch);
  },
});

contextBridge.exposeInMainWorld('bcHistory', {
  get:    () => invoke('data:history:get'),
  add:    (entry) => {
    if (!entry || typeof entry.url !== 'string') return Promise.reject(new Error('Invalid entry'));
    return invoke('data:history:add', { url: entry.url, title: entry.title, favicon: entry.favicon });
  },
  clear:  () => invoke('data:history:clear'),
  // [SEC-C] export: dialog is owned by main — renderer cannot control save path
  export: () => invoke('data:history:export'),
});

contextBridge.exposeInMainWorld('bcNotes', {
  get:  ()     => invoke('data:notes:get'),
  save: (text) => {
    if (typeof text !== 'string') return Promise.reject(new Error('Notes must be string'));
    return invoke('data:notes:save', text);
  },
});

contextBridge.exposeInMainWorld('bcTabs', {
  get:  () => invoke('data:tabs:get'),
  save: (tabs) => {
    if (!Array.isArray(tabs)) return Promise.reject(new Error('Tabs must be array'));
    return invoke('data:tabs:save', tabs);
  },
});

// ─── Dialog ───────────────────────────────────────────────────────────────────
// [SEC-D] Previously the renderer called bcDialog.showSave() with a full path
// and filter config — giving it control over where files land.
// Now dialog is owned entirely by main; renderer only calls "export history".
contextBridge.exposeInMainWorld('bcDialog', {
  // Returns { canceled: bool, filePath?: string }
  showSaveHistory: () => invoke('data:history:export'),
});

// ─── Webview / session ────────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('bcWebview', {
  clearSession: (partitionId) => {
    if (typeof partitionId !== 'string' || !/^tab-[a-z0-9]{6,20}$/.test(partitionId)) {
      return Promise.reject(new Error('Invalid partitionId'));
    }
    return invoke('webview:clearSession', partitionId);
  },
  isSafeUrl: (url) => {
    if (typeof url !== 'string' || url.length > 2048) return Promise.resolve(false);
    return invoke('webview:isSafeUrl', url);
  },
  trustedHosts: () => invoke('webview:trustedHosts'),
  openPath:     () => invoke('app:openPath'), // no argument — opens DATA_DIR only
});

// ─── Auto-updater ─────────────────────────────────────────────────────────────
contextBridge.exposeInMainWorld('bcUpdater', {
  check:         () => invoke('updater:check'),
  // [SEC-E] installNow requires explicit user confirmation — see updater.js
  installNow:    () => invoke('updater:install'),
  installOnQuit: () => invoke('updater:installOnQuit'),

  onStatus: (cb) => {
    if (typeof cb !== 'function') return () => {};
    const handler = (_, data) => {
      if (!data || typeof data !== 'object') return;
      // Validate and clone — never forward raw IPC data
      cb({
        state:   ['idle','checking','downloading','ready','error'].includes(data.state) ? data.state : 'idle',
        version: typeof data.version === 'string' ? data.version.slice(0, 32) : undefined,
        message: typeof data.message === 'string' ? data.message.slice(0, 256) : undefined,
      });
    };
    ipcRenderer.on('updater:status', handler);
    return () => ipcRenderer.off('updater:status', handler);
  },
  onProgress: (cb) => {
    if (typeof cb !== 'function') return () => {};
    const handler = (_, data) => {
      if (!data || typeof data !== 'object') return;
      cb({
        percent: typeof data.percent === 'number' ? Math.min(100, Math.max(0, data.percent)) : 0,
        speed:   typeof data.speed   === 'number' ? data.speed   : 0,
        total:   typeof data.total   === 'number' ? data.total   : 0,
      });
    };
    ipcRenderer.on('updater:progress', handler);
    return () => ipcRenderer.off('updater:progress', handler);
  },
});
